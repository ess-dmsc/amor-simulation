# Changes

* Repetition of messages will now be triggered only if no new message has been received within the configurable repetition time (`pv-update-period`).

